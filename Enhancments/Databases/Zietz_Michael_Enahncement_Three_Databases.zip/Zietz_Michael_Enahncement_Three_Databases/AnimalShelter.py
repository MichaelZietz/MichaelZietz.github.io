#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov 15 20:02:15 2023

@author: michaelzietz_snhu
"""

from pymongo import MongoClient
from bson.objectid import ObjectId


class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, USER, PASS, DB, COL):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Initialize Connection via SCRAM-SHA-256 encryption
        #
        self.client = MongoClient('mongodb://localhost:27017',
                                  username=USER,
                                  password=PASS,
                                  authSource='admin',
                                  authMechanism='SCRAM-SHA-256')
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
        print("Connection Successful")

    # This create method implements the C in CRUD.
    def create(self, data):
        # confirm data is not empty otherwise throws exception
        if len(data) < 1:
            return False

        elif data is not None:
            # inserts a single element with given data
            self.database.animals.insert_one(data)
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    # This read method implements the R in CRUD.
    def read(self, search):
        searchResult = []  # initialize empty list so it can be filled or empty
        # confirm search data is not empty data otherwise throws exception
        if search is not None:
            # searches database and returns all matching entries
            searchResult = self.database.animals.find(search)
        else:
            raise Exception("Nothing to read, because data parameter is empty")
        return searchResult  # returns empty or filled list

    # This update method implements the U in CRUD
    def update(self, searchData, updateData):
        # confirm searchData is not empty data otherwise throws exception
        if searchData is not None:
            if searchData:
                # updates all specified entries and updates accordingly
                updateResult = self.database.animals.update_many(searchData, {"$set": updateData})
                return updateResult.raw_result
        else:
            raise Exception("Nothing to update, because data parameter is empty")

    # This delete method implements the D in CRUD
    def delete(self, search):
        # confirm search data is not empty data otherwise throws exception
        if search is not None:
            if search:
                # deletes all entries found possessing given search data
                deleteResult = self.database.animals.delete_many(search)
                return deleteResult.raw_result
        else:
            raise Exception("Nothing to delete, because data parameter is empty")
