package com.example.cs499_software_design_enhancement;

import static java.lang.Integer.parseInt;

import java.util.ArrayList;
import java.util.Random;

public class Enemy {

    // Creates private variables
    private String name;
    private int currentHP;
    private int maxHP;
    private int accuracy;
    private int damage;
    Random rand = new Random();
    protected String[] enemyNames = {"Dragon", "Slime", "Goblin", "Lich", "Dark ELf", "Zombie", "Wolf"};

    // Creates get functions for private variables
    public String getName() { return name; }
    public int getCurrentHP() { return currentHP; }
    public int getMaxHP() { return maxHP; }
    public int getAccuracy() { return accuracy; }
    public int getDamage() { return damage; }

    // Creates set functions for private variables
    public void setName(String name)
    {
        this.name = name;
    }
    public void setCurrentHP(int currentHP)
    {
        this.currentHP = currentHP;
    }
    public void setMaxHP(int maxHP)
    {
        this.maxHP = maxHP;
    }
    public void setAccuracy(int accuracy)
    {
        this.accuracy = accuracy;
    }
    public void setDamage(int damage)
    {
        this.damage = damage;
    }

    // Default class constructor with no requirements
    public Enemy() {
        // Initialize single random instance of enemy stats
        int hp = CreateEnemyIntegers()[0];
        int accuracy = CreateEnemyIntegers()[1];
        int damage = CreateEnemyIntegers()[2];

        // Initialize class variables with randomized numbers and name
        // Enemies should always be initialized at full HP
        this.name = CreateEnemyName();
        this.maxHP = hp;
        this.currentHP = hp;
        this.accuracy = accuracy;
        this.damage = damage;
    }

    // Class constructor with ONE requirement (Enemy HP scales with rounds)
    public Enemy(int round) {
        // Initialize single random instance of enemy stats
        int hp = CreateEnemyIntegers()[0] * round;
        int accuracy = CreateEnemyIntegers()[1];
        int damage = CreateEnemyIntegers()[2];

        // Initialize class variables with randomized numbers and name
        // Enemies should always be initialized at full HP
        this.name = CreateEnemyName();
        this.maxHP = hp;
        this.currentHP = hp;
        this.accuracy = accuracy;
        this.damage = damage;
    }

    public String CreateEnemyName() {
        int randName = rand.nextInt(7);
        return enemyNames[randName];
    }

    public int[] CreateEnemyIntegers() {
        int initialHP = 10;
        int randAccuracy = rand.nextInt(100);
        int randDamage = rand.nextInt(20);
        return new int[]{initialHP, randAccuracy, randDamage};
    }

    public int EnemyAttackAccuracy() {
        // Obtain a random percentage (x100)
        int attackRoll = rand.nextInt(100);
        int result = 0;

        // Determine if the roll was a critical and auto-success hit
        if (attackRoll == 99) {
            result = attackRoll;
        }
        // Determines if the attack roll hits for each class
        else if (attackRoll < accuracy) {
            result = attackRoll;
        }
        // returns the successful attack roll
        // or 0 if it was a miss
        return result;
    }

    public int EnemyAttackDamage(boolean critAttack) {
        int result = damage;

        // If the attack is a critical hit, double the damage
        if (critAttack) {
            result *= 2;
        }
        // returns calculated damage
        // left 0 if issue determining class name or damage
        return result;
    }
}
