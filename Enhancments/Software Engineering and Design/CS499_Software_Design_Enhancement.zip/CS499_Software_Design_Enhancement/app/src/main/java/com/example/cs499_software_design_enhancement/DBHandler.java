package com.example.cs499_software_design_enhancement;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.Cursor;
import java.util.ArrayList;

public class DBHandler extends SQLiteOpenHelper {

    // Creates name variable for database
    private static final String DB_NAME = "relentlessheroesdb";

    // Database Version
    private static final int DB_VERSION = 3;

    // Heroes DB Table and Columns
    private static final String TABLE_HEROES = "heroes";
    private static final String ID_COL = "id";
    private static final String NAME_COL = "name";
    private static final String CLASS_COL = "class";
    private static final String TOTAL_DAMAGE_COL = "totalDamage";
    private static final String TOTAL_ROUNDS_COL = "totalRounds";

    // Users DB Table and Columns
    private static final String TABLE_USERS = "users";
    private static final String USERNAME_COL = "username";
    private static final String PASSWORD_COL = "password";


    // Constructs database handler.
    public DBHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    // Creates database by running a sqlite query for each table
    @Override
    public void onCreate(SQLiteDatabase db) {

        // Creates Weights Table
        String queryHeroes = "CREATE TABLE " + TABLE_HEROES + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + NAME_COL + " TEXT,"
                + CLASS_COL + " TEXT,"
                // + MAX_HP_COL + "TEXT,"
                // + CURRENT_HP_COL + "TEXT,"
                // + BASE_ACCURACY_COL + "TEXT,"
                // + BASE_DAMAGE_COL + "TEXT,"
                + TOTAL_DAMAGE_COL + " TEXT,"
                + TOTAL_ROUNDS_COL + " TEXT)";
        db.execSQL(queryHeroes);

        // Creates Users Table
        String queryUser = "CREATE TABLE " + TABLE_USERS + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + USERNAME_COL + " TEXT,"
                + PASSWORD_COL + " TEXT)";
        db.execSQL(queryUser);


    }

    // This function adds a new hero entry to Heroes Table: Crud
    public void addNewHero(String nameString, String classString, String damageString, String
            roundsString) {

        // Creates writable SQL database
        SQLiteDatabase db = this.getWritableDatabase();

        // Creates variable for content values
        ContentValues values = new ContentValues();

        // Passes all values with key and value respectively
        values.put(NAME_COL, nameString);
        values.put(CLASS_COL, classString);
        values.put(TOTAL_DAMAGE_COL, damageString);
        values.put(TOTAL_ROUNDS_COL, roundsString);

        // Inserts new data into table
        db.insert(TABLE_HEROES, null, values);
        // Closes db
        db.close();
    }

    // This method adds a new user entry to User Table: Crud
    public void addNewUser(String userName, String passWord) {

        // Creates writable SQL database
        SQLiteDatabase db = this.getWritableDatabase();

        // Creates variable for content values
        ContentValues values = new ContentValues();

        // Passes all values with key and value respectively
        values.put(USERNAME_COL, userName);
        values.put(PASSWORD_COL, passWord);

        // Inserts new data into table
        db.insert(TABLE_USERS, null, values);
        // Closes db
        db.close();
    }

    // This method reads all usernames from User Table : cRud
    // Returns a boolean depending if a match is found
    // Used for creating new user accounts
    public boolean readUsername(String userName) {
        boolean accountExists = false;
        SQLiteDatabase db = this.getReadableDatabase();

        // Queries database for matching usernames
        String sql = "select * from " + TABLE_USERS + " where " + USERNAME_COL + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { userName });

        // Moves cursor to first position.
        if (cursor.moveToFirst()) {
            do {
                // If the current username matches the search then error is diplayed
                if (cursor.getString(1).equals(userName)) {
                    accountExists = true;
                }
            } while (cursor.moveToNext());
            // Moves cursor to next
        }
        // Closes cursor and returns boolean
        cursor.close();
        return accountExists;
    }

    // This method reads all usernames and passwords from User Table : cRud
    // Returns a boolean depending if a match for both variables is found
    // Used for signing into existing accounts
    public boolean readUsernameAndPassword(String userName, String passWord) {
        boolean accountExists = true;
        SQLiteDatabase db = this.getReadableDatabase();

        // Queries database for matching usernames
        String sql = "select * from " + TABLE_USERS + " where " + USERNAME_COL + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { userName });

        // Moves cursor to first position.
        if (cursor.moveToFirst()) {
            do {
                // If matching usernames possess the same password allows sign in
                if (cursor.getString(1).equals(userName) && cursor.getString(2).equals(passWord)) {
                    accountExists = false;
                }
            } while (cursor.moveToNext());
            // Moves cursor to next
        }
        // Closes cursor and returns boolean
        cursor.close();
        return accountExists;
    }

    // This method reads all hero entries from Heros Table : cRud
    // Returns an ArrayList filled with Hero class objects
    // Used for data manipulation like updating and deleting entries
    public ArrayList<Hero> readHeroes() {
        SQLiteDatabase db = this.getReadableDatabase();

        // Queries Weight Table for all entries
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_HEROES, null);

        // Creates a new array list.
        ArrayList<Hero> herosArrayList = new ArrayList<>();

        // Move cursor to first position
        if (cursor.moveToFirst()) {
            do {
                // Adds cursor data to array list
                // Index1 = heroName; Index2 = className ; Index3 = totalDamage ; Index4 = totalRounds
                herosArrayList.add(new Hero(cursor.getString(1),
                        cursor.getString(2),
                        cursor.getString(3),
                        cursor.getString(4)));
            } while (cursor.moveToNext());
            // Moves cursor to next
        }
        // Closes cursor and returns array list
        cursor.close();
        return herosArrayList;
    }

    // This method checks if the table exists already
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_HEROES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }
}