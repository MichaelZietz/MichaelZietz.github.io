package com.example.cs499_software_design_enhancement;


import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.io.Serializable;

public class ActivityCombat extends AppCompatActivity {
    private Button createFleeButton;
    private Button createFightButton;
    private TextView currentRoundText;
    private TextView enemyText;
    private TextView heroText;
    private TextView combatText;
    private DBHandler dbHandler;

    public int round;

    // This function creates the screen for simulating combat between the hero and enemies
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_combat);

        // Initialize database handler
        dbHandler = new DBHandler(ActivityCombat.this);

        Intent i = getIntent();
        Hero currentHero = new Hero(i.getStringExtra("newHeroName"), i.getIntExtra("newHeroClass", 0));
        Enemy currentEnemy = new Enemy();

        // Identify screen elements
        currentRoundText = (TextView) findViewById(R.id.textViewCurrentRound);
        enemyText = (TextView) findViewById(R.id.textViewEnemy);
        heroText = (TextView) findViewById(R.id.textViewHero);
        combatText = (TextView) findViewById(R.id.textViewCombat);
        createFleeButton = (Button) findViewById(R.id.buttonFlee);
        createFightButton = (Button) findViewById(R.id.buttonFight);

        // Enable all buttons
        createFleeButton.setEnabled(true);
        createFightButton.setEnabled(true);

        // Creates a click listener for submitting a new vanguard hero
        createFleeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SubmitFlee(currentHero);
            }
        });

        // Creates a click listener for submitting a new warlock hero
        createFightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SubmitFight(currentHero, currentEnemy);
            }
        });

        // START Combat
        // Initialize Rounds at 1
        round = 1;
        currentRoundText.setText(Integer.toString(round));

        // Initialize enemy
        String combatEnemyText = currentEnemy.getName() + ": " + currentEnemy.getCurrentHP() + "/" + currentEnemy.getMaxHP();
        enemyText.setText(combatEnemyText);

        // Initialize hero
        String combatHeroText = currentHero.getHeroName() + ": " + currentHero.getCurrentHP()
                + "/" + currentHero.getMaxHP();
        heroText.setText(combatHeroText);

        // Initialize Combat Text
        String combatViewText = "Press the Fight button to attack and start combat\nPress the Flee button to accept defeat";
        combatText.setText(combatViewText);

    }

    // This button's function is intended to skip the rest of combat, kill the current hero, and
    // jump to the match history screen
    public void SubmitFlee(Hero currentHero) {
        if (currentHero != null) {
            String damage = Integer.toString(currentHero.getTotalDamage());
            String rounds = Integer.toString(currentHero.getTotalRounds());
            dbHandler.addNewHero(currentHero.getHeroName(), currentHero.getClassName(), damage, rounds);
        }

        Intent intent = new Intent(this, ActivityDefeat.class);
        intent.putExtra("heroNameScore", currentHero.getHeroName());
        intent.putExtra("roundScore", currentHero.getTotalRounds());
        startActivity(intent);
    }

    // This button creates the functionality for progressing combat
    public void SubmitFight(Hero currentHero, Enemy currentEnemy) {
        if (currentHero.getCurrentHP() != 0 && currentEnemy.getCurrentHP() != 0) {

            // HERO ATTACKS
            int heroAttackAccuracy = currentHero.HeroAttackAccuracy();
            // Determine if the Current Hero's attack misses the Enemy
            if (heroAttackAccuracy != 0) {
                int damage;
                // Determine if the confirmed hit was a critical hit
                // Otherwise do normal damage
                if (heroAttackAccuracy == 99) {
                    damage = currentHero.HeroAttackDamage(true);
                    currentEnemy.setCurrentHP(currentEnemy.getCurrentHP() - damage );
                } else {
                    damage = currentHero.HeroAttackDamage(false);
                    currentEnemy.setCurrentHP(currentEnemy.getCurrentHP() - damage);
                }
                // Increment Hero's damage record after hit
                currentHero.setTotalDamage(currentHero.getTotalDamage() + damage);

                // Reprint Enemy HP bar
                String combatEnemyText = currentEnemy.getName() + ": " + currentEnemy.getCurrentHP() + "/" + currentEnemy.getMaxHP();
                enemyText.setText(combatEnemyText);
            }

            // ENEMY ATTACKS
            // Check to see if the Current Enemy is still alive before attacking Hero
            if (currentEnemy.getCurrentHP() != 0) {
                int enemyAttackAccuracy = currentEnemy.EnemyAttackAccuracy();
                // Determine if the Current Enemy's attack misses the Hero
                if (enemyAttackAccuracy != 0) {
                    // Determine if the confirmed hit was a critical hit
                    // Otherwise do normal damage
                    if (enemyAttackAccuracy == 99) {
                        currentHero.setCurrentHP(currentHero.getCurrentHP() - currentEnemy.EnemyAttackDamage(true));
                    } else {
                        currentHero.setCurrentHP(currentHero.getCurrentHP() - currentEnemy.EnemyAttackDamage(false));
                    }
                }
                // Reprint Hero HP bar
                String combatHeroText = currentHero.getHeroName() + ": " + currentHero.getCurrentHP()
                        + "/" + currentHero.getMaxHP();
                heroText.setText(combatHeroText);
            }

        } else if (currentHero.getCurrentHP() != 0 && currentEnemy.getCurrentHP() == 0) {
            // Set Hero's round score to round succeeded and BEFORE round increment
            currentHero.setTotalRounds(round);
            // Increment round after succeeded
            round += 1;
            currentRoundText.setText(Integer.toString(round));

            // Initialize new enemy
            currentEnemy = new Enemy(round);

            String combatEnemyText = currentEnemy.getName() + ": " + currentEnemy.getCurrentHP() + "/" + currentEnemy.getMaxHP();
            enemyText.setText(combatEnemyText);
        }

        else {
            String damage = Integer.toString(currentHero.getTotalDamage());
            String rounds = Integer.toString(currentHero.getTotalRounds());
            dbHandler.addNewHero(currentHero.getHeroName(), currentHero.getClassName(), damage, rounds);

            Intent intent = new Intent(this, ActivityDefeat.class);
            intent.putExtra("heroNameScore", currentHero.getHeroName());
            intent.putExtra("roundScore", currentHero.getTotalRounds());
            startActivity(intent);
        }
    }
}
