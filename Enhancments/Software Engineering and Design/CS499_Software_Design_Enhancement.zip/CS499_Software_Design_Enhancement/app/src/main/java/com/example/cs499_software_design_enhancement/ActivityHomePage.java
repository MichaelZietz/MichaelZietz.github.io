package com.example.cs499_software_design_enhancement;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityHomePage extends AppCompatActivity {

    private Button createHeroButton;

    // This function creates the screen for the welcome page
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        createHeroButton = (Button) findViewById(R.id.buttonCreateHero);

        // Sets button to enabled
        createHeroButton.setEnabled(true);

        // Creates click listener for createHeroButton to navigate to the next activity/screen
        createHeroButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { CreateHeroSubmit(); }
        });
    }

    protected void CreateHeroSubmit() {
        Intent intent = new Intent(this, ActivityCreateHero.class);
        startActivity(intent);
    }
}
