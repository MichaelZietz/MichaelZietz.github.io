package com.example.cs499_software_design_enhancement;
import java.util.Random;
import java.io.Serializable;

public class Hero implements Serializable{

    // Creates private variables
    private String heroName;
    private String className;
    private String totalDamageString;
    private String totalRoundsString;
    private int maxHP;
    private int currentHP;
    private int baseAccuracy;
    private int baseDamage;
    private int totalDamage;
    private int totalRounds;
    Random rand = new Random();

    // Creates class lists where
    // [0] = Vangaurd
    // [1] = Warlock
    // [2] = Hunter
    protected String[] classChoice = {"Vanguard", "Warlock", "Hunter"};
    protected int[] classHP = {100, 80, 60};
    protected int[] classAccuracy = {60, 75, 90};
    protected int[] classDamage = {10, 6, 4};


    // Creates get functions for private variables
    public String getHeroName() { return heroName; }
    public String getClassName() { return className; }
    public String getTotalDamageString() { return totalDamageString; }
    public String getTotalRoundsString() { return totalRoundsString; }
    public int getMaxHP() { return maxHP; }
    public int getCurrentHP() { return currentHP; }
    public int getBaseAccuracy() { return baseAccuracy; }
    public int getBaseDamage() { return baseDamage; }
    public int getTotalDamage() { return totalDamage; }
    public int getTotalRounds() { return totalRounds; }


    // Creates set functions for private variables
    public void setHeroName(String heroName)
    {
        this.heroName = heroName;
    }
    public void setClassName(String className) { this.className = className; }
    public void setMaxHP(int maxHP) { this.maxHP = maxHP; }
    public void setCurrentHP(int currentHP)
    {
        this.currentHP = currentHP;
    }
    public void setAccuracy(int baseAccuracy)
    {
        this.baseAccuracy = baseAccuracy;
    }
    public void setBaseDamage(int baseDamage)
    {
        this.baseDamage = baseDamage;
    }
    public void setTotalDamage(int totalDamage)
    {
        this.totalDamage = totalDamage;
    }
    public void setTotalRounds(int totalRounds)
    {
        this.totalRounds = totalRounds;
    }

    // Constructor for HeroClass that creates a character for the purposes of simulated combat
    public Hero (String heroName, int userChoice) {
        this.heroName = heroName;
        this.className = classChoice[userChoice];
        this.maxHP = classHP[userChoice];
        this.currentHP = classHP[userChoice];
        this.baseAccuracy = classAccuracy[userChoice];
        this.baseDamage = classDamage[userChoice];
        this.totalDamage = 0;
        this.totalRounds = 0;
    }

    public Hero (String heroName, String className, String totalDamage, String totalRounds) {
        this.heroName = heroName;
        this.className = className;
        this.totalDamageString = totalDamage;
        this.totalRoundsString = totalRounds;
    }

    public int HeroAttackAccuracy() {
        // Obtain a random percentage (x100)
        int attackRoll = rand.nextInt(100);
        int result = 0;

        // Determine if the roll was a critical and auto-success hit
        if (attackRoll == 99) {
            result = attackRoll;
        }
        // Determines if the attack roll hits for each class
        else if ((this.className.equals(classChoice[0])) && (attackRoll > (100 - classAccuracy[0]))) {
            result = attackRoll;
        } else if ((this.className.equals(classChoice[1])) && (attackRoll > (100 - classAccuracy[1]))) {
            result = attackRoll;
        } else if ((this.className.equals(classChoice[2])) && (attackRoll > (100 - classAccuracy[2]))) {
            result = attackRoll;
        }
        // returns the successful attack roll
        // or 0 if it was a miss
        return result;
    }

    public int HeroAttackDamage(boolean critAttack) {
        int result = 0;
        if (this.className.equals(classChoice[0])) {
            result = classDamage[0]; // + getUserBaseDamage();
        }
        else if (this.className.equals(classChoice[1])) {
            result = classDamage[0]; // + getUserBaseDamage();
        }
        else if (this.className.equals(classChoice[2])) {
            result = classDamage[0]; // + getUserBaseDamage();
        }
        // If the attack is a critical hit, double the damage
        if (critAttack) {
            result *= 2;
        }
        // returns calculated damage
        // left 0 if issue determining class name or damage
        return result;
    }

}
