package com.example.cs499_software_design_enhancement;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
public class HeroRVAdapter extends RecyclerView.Adapter<HeroRVAdapter.ViewHolder> {
    // Creates variables for array list and context
    private ArrayList<Hero> heroArrayList;
    private Context context;

    // Creates the constructor
    public HeroRVAdapter(ArrayList<Hero> heroArrayList, Context context) {
        this.heroArrayList = heroArrayList;
        this.context = context;
    }

    // This method inflates layout file for recycler view items.
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.heroes_history_card, parent, false);
        return new ViewHolder(view);
    }

    // This method binds holders for hero objects
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // Sets data to views of recycler view item.
        Hero hero = heroArrayList.get(position);
        holder.heroName.setText("Name: " + hero.getHeroName());
        holder.heroClass.setText("Class: " + hero.getClassName());
        holder.heroDamage.setText("Damage: " + hero.getTotalDamageString());
        holder.heroRounds.setText("Rounds: " + hero.getTotalRoundsString());
    }

    // This method returns the size of array list
    @Override
    public int getItemCount() {
        return heroArrayList.size();
    }

    // This class defines ViewHolders
    public class ViewHolder extends RecyclerView.ViewHolder {

        // Creates variables for text views.
        private TextView heroName, heroClass, heroDamage, heroRounds;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // Initializes text views using screen elements
            heroName = itemView.findViewById(R.id.viewTextName);
            heroClass = itemView.findViewById(R.id.viewTextClass);
            heroRounds = itemView.findViewById(R.id.viewTextRounds);
            heroDamage = itemView.findViewById(R.id.viewTextDamage);
        }
    }
}
