package com.example.cs499_software_design_enhancement;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;

import androidx.core.view.WindowCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    //private ActivityMainBinding binding;
    private Button loginButton;
    private Button createAccountButton;
    private TextView loginErrorText;
    private EditText usernameText;
    private EditText passwordText;
    private DBHandler dbHandler;

    // This method creates the initial, login screen
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initializes login screen elements
        usernameText = (EditText) findViewById(R.id.editTextUsername);
        passwordText = (EditText) findViewById(R.id.editTextPassword);
        loginErrorText = (TextView) findViewById(R.id.textViewLoginError);
        loginButton = (Button) findViewById(R.id.buttonLogin);
        createAccountButton = (Button) findViewById(R.id.buttonCreateAccount);

        // Sets both buttons to enabled
        loginButton.setEnabled(true);
        createAccountButton.setEnabled(true);

        // Creates a database handler
        dbHandler = new DBHandler(MainActivity.this);

        // Creates click listener for loginButton
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoginUser();
            }
        });

        // Creates click listener for createAccountButton
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CreateUser();
            }
        });
    }

    // This function is called when user attempts to login to existing account
    // Succeeds login and navigates to grid screen if matching username and password is found
    // Otherwise displays error message when incorrect/empty
    public void LoginUser() {
        String name = usernameText.getText().toString();
        String pass = passwordText.getText().toString();
        if (name.isEmpty() || pass.isEmpty() || dbHandler.readUsernameAndPassword(name, pass)) {
            loginErrorText.setText("Invalid username or password.");
        }
        else {
            loginErrorText.setText("");
            Intent intent = new Intent(this, ActivityHomePage.class);
            startActivity(intent);
        }
    }

    // This function is called when user attempts to create a new account
    // Succeeds login and navigates to setting goal screen if matching username and password is NOT found
    // Saves this new account info in Users Table
    // Otherwise displays error message when incorrect/empty
    public void CreateUser() {
        String name = usernameText.getText().toString();
        String pass = passwordText.getText().toString();
        if (name.isEmpty() || pass.isEmpty()) {
            loginErrorText.setText("Invalid username or password.");
        }
        else if (dbHandler.readUsername(name)) {
            loginErrorText.setText("We're sorry. That username already exists. Please try again.");
        }
        else {
            dbHandler.addNewUser(name, pass);
            loginErrorText.setText("");
            Intent intent = new Intent(this, ActivityHomePage.class);
            startActivity(intent);
        }
    }
}