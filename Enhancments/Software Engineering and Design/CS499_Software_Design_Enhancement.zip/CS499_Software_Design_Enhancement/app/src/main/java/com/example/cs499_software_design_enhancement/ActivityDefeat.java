package com.example.cs499_software_design_enhancement;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.io.Serializable;
import java.util.ArrayList;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class ActivityDefeat extends AppCompatActivity {
    private Button homePageButton;
    private Button tryAgainButton;
    private TextView heroScoreText;
    private DBHandler dbHandler;
    private ArrayList<Hero> heroArrayList;
    private HeroRVAdapter heroRVAdapter;
    private RecyclerView heroesRV;

    // This function creates the screen for simulating combat between the hero and enemies
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_defeat);

        // Initialize array list and database handler
        heroArrayList = new ArrayList<>();
        dbHandler = new DBHandler(ActivityDefeat.this);

        // Retrieve filled list from handler
        heroArrayList = dbHandler.readHeroes();

        // Pass array list to adapter class
        heroRVAdapter = new HeroRVAdapter(heroArrayList, ActivityDefeat.this);
        heroesRV = findViewById(R.id.recyclerViewHeroes);

        // Set layout manager for our recycler view.
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(ActivityDefeat.this, RecyclerView.VERTICAL, false);
        heroesRV.setLayoutManager(linearLayoutManager);

        // Set adapter to recycler view.
        heroesRV.setAdapter(heroRVAdapter);

        // Identify screen elements
        heroScoreText = (TextView) findViewById(R.id.textViewHeroScore);
        homePageButton = (Button) findViewById(R.id.buttonHomePage);
        tryAgainButton = (Button) findViewById(R.id.buttonTryAgain);

        // Populate Defeated Hero's Score Text Field
        Intent i = getIntent();
        String scoreText = i.getStringExtra("heroNameScore") + " vanquished " + i.getIntExtra("roundScore", 0) + " enemies.";
        heroScoreText.setText(scoreText);

        // Enable all buttons
        homePageButton.setEnabled(true);
        tryAgainButton.setEnabled(true);

        // Creates a click listener for submitting a new vanguard hero
        homePageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SubmitHomePage();
            }
        });

        // Creates a click listener for submitting a new warlock hero
        tryAgainButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SubmitTryAgain();
            }
        });
    }

    // This button's function is intended navigate the user to the Home Screen
    public void SubmitHomePage() {
        Intent intent = new Intent(this, ActivityHomePage.class);
        startActivity(intent);
    }

    // This button's function is intended navigate the user to the Hero Creation screen to try again
    public void SubmitTryAgain() {
        Intent intent = new Intent(this, ActivityCreateHero.class);
        startActivity(intent);
    }


}
