package com.example.cs499_software_design_enhancement;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;



public class ActivityCreateHero extends AppCompatActivity {

    private Button createVanguardButton;
    private Button createWarlockButton;
    private Button createHunterButton;
    private EditText heroNameText;
    private DBHandler dbHandler;

    // This function creates the screen for creating a singular, new hero
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_hero);

        // Initialize database handler
        dbHandler = new DBHandler(ActivityCreateHero.this);

        // Identify screen elements
        heroNameText = (EditText) findViewById(R.id.editTextHeroName);
        createVanguardButton = (Button) findViewById(R.id.buttonCreateVanguard);
        createWarlockButton = (Button) findViewById(R.id.buttonCreateWarlock);
        createHunterButton = (Button) findViewById(R.id.buttonCreateHunter);

        // Enable all buttons
        createVanguardButton.setEnabled(true);
        createWarlockButton.setEnabled(true);
        createHunterButton.setEnabled(true);

        // Creates a click listener for submitting a new vanguard hero
        createVanguardButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SubmitVanguard();
            }
        });

        // Creates a click listener for submitting a new warlock hero
        createWarlockButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SubmitWarlock();
            }
        });

        // Creates a click listener for submitting a new hunter hero
        createHunterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SubmitHunter();
            }
        });
    }

    // This button's function selected the Vanguard class for the hero
    public void SubmitVanguard() {
        String name = heroNameText.getText().toString();
        if (name.isEmpty()) {
            heroNameText.setHint("Please enter a name");
        }
        else {
            Intent intent = new Intent(this, ActivityCombat.class);
            intent.putExtra("newHeroName", name);
            intent.putExtra("newHeroClass", 0);
            startActivity(intent);
        }
    }

    // This button's function selected the Warlock class for the hero
    public void SubmitWarlock() {
        String name = heroNameText.getText().toString();
        if (name.isEmpty()) {
            heroNameText.setHint("Please enter a name");
        }
        else {
            Hero hero = new Hero(name, 1);
            Intent intent = new Intent(this, ActivityCombat.class);
            intent.putExtra("newHeroName", name);
            intent.putExtra("newHeroClass", 1);
            startActivity(intent);
        }
    }

    // This button's function selected the Hunter class for the hero
    public void SubmitHunter() {
        String name = heroNameText.getText().toString();
        if (name.isEmpty()) {
            heroNameText.setHint("Please enter a name");
        }
        else {
            Hero hero = new Hero(name, 2);
            Intent intent = new Intent(this, ActivityCombat.class);
            intent.putExtra("newHeroName", name);
            intent.putExtra("newHeroClass", 2);
            startActivity(intent);
        }
    }
}
