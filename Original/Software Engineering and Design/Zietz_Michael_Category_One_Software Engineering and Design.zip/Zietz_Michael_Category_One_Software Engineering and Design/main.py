import Characters
import Weapons

try:

    c = Characters.Character()
    w = Weapons.Weapon()

    run_program = True
    while run_program:
        # start with menu options
        def main_menu():
            print("Please choose one of the following options:\n"
                  "1. Characters\n"
                  "2. Weapons\n"
                  "3. Start Combat!!\n"
                  "4. Quit")

        def character_menu():
            print("Please choose one of the following options:\n"
                  "1. Add a new character\n"
                  "2. Edit a current character\n"
                  "3. Clear character list\n"
                  "4. Go back")

        def weapon_menu():
            print("Please choose one of the following options:\n"
                  "1. Add a new weapon\n"
                  "2. Edit a current weapon\n"
                  "3. Clear weapon list\n"
                  "4. Go back")

        def combat():
            combat_bool = True
            while combat_bool:
                roll_character_choice = Characters.Character.select_character(c)
                roll_weapon_choice = Weapons.Weapon.select_weapon(w)

                if roll_character_choice is None or roll_weapon_choice is None:
                    print("ERROR: There are no characters or weapons to choose.\n"
                          "Press Enter to continue...")
                    break

                else:
                    combat_rolling_bool = True
                    while combat_rolling_bool:
                        Characters.Character.rolling_attack(c, roll_character_choice)
                        Weapons.Weapon.rolling_damage(w, roll_weapon_choice)
                        print("Roll again? (Y/N)")
                        roll_again = input()
                        roll_again_bool = True
                        while roll_again_bool:
                            if roll_again.upper() == 'Y':
                                roll_again_bool = False
                            elif roll_again.upper() == 'N':
                                combat_bool = False
                                pass
                            else:
                                print("ERROR: Please enter Y or N")

        main_menu()
        main_menu_choice = int(input())
        if main_menu_choice == 1:
            print("Characters")
            run_character_menu = True
            while run_character_menu:
                character_menu()
                character_menu_choice = int(input())

                if character_menu_choice == 1:
                    print("Add a new character:")
                    Characters.Character.add_character(c)
                    pass

                elif character_menu_choice == 2:
                    print("Edit a current character:")
                    Characters.Character.edit_character(c)
                    pass

                elif character_menu_choice == 3:
                    Characters.Character.clear_character_list(c)
                    pass

                elif character_menu_choice == 4:
                    print("Returning to Main Menu:")
                    break

                else:
                    print("ERROR: Please enter a number from 1 to 4")
                    pass

        if main_menu_choice == 2:
            print("Weapons")
            run_weapon_menu = True
            while run_weapon_menu:
                weapon_menu()
                weapon_menu_choice = int(input())

                if weapon_menu_choice == 1:
                    print("Add a new weapon:")
                    Weapons.Weapon.add_weapon(w)
                    pass

                elif weapon_menu_choice == 2:
                    print("Edit a current weapon:")
                    Weapons.Weapon.edit_weapon(w)
                    pass

                elif weapon_menu_choice == 3:
                    Weapons.Weapon.clear_weapon_list(w)
                    pass

                elif weapon_menu_choice == 4:
                    print("Returning to Main Menu:")
                    break

                else:
                    print("ERROR: Please enter a number from 1 to 4")
                    pass

        elif main_menu_choice == 3:
            print("Initiating Combat:")
            combat()
            pass

        elif main_menu_choice == 4:
            print("Ending Program:")
            run_program = False
            pass

        else:
            print("ERROR: Please enter a number from 1 to 4")
            pass

except:
    print("ERROR: An exception has occurred")
