from random import randint

class Weapon(object):
    weapon_list = []

    def __init__(self):
        self.weapon_name = ""
        self.weapon_damage_dice_num = 0
        self.weapon_damage_die = 0
        self.weapon_damage_type = ""

    def enter_weapon(self):
        self.weapon_name = input("Please enter the weapon's name: \n")
        self.weapon_damage_dice_num = int(input("Please enter how many die/dice are rolled per attack: \n"))
        self.weapon_damage_die = int(input("Please enter how many sides are on the weapon's die/dice: \n"))
        self.weapon_damage_type = input("Please enter the weapon's damage type: \n")

    def display_entered_weapons(self):
        print("Weapon: ", self.weapon_name)
        print("Damage: ", self.weapon_damage_dice_num, "D", self.weapon_damage_die, " ", self.weapon_damage_type)

    def get_weapon_name(self):
        return self.weapon_name

    def get_weapon_damage_dice_num(self):
        return self.weapon_damage_dice_num

    def get_weapon_damage_die(self):
        return self.weapon_damage_die

    def get_weapon_damage_type(self):
        return self.weapon_damage_type

    def clear_weapon_list(self):
        # This function clears the weapon_list
        print("Weapon list has been cleared:")
        self.weapon_list.clear()

    def print_weapon_list(self):
        # This function prints the list of weapons
        weapon_list_length = len(self.weapon_list)
        weapon_index = 0
        for i in range(weapon_list_length):
            weapon_index = weapon_index + 1
            print(weapon_index, ". ")
            self.weapon_list[i].display_entered_weapons()
            print("")

    def add_weapon(self):
        # This function adds a new weapon object(s) to list of character objects
        num_of_weapons_bool = True
        while num_of_weapons_bool:
            num_of_weapons = int(input("How many weapons would you like to create? "))
            if num_of_weapons >= 1:
                for i in range(num_of_weapons):
                    w = Weapon()
                    w.enter_weapon()
                    self.weapon_list.append(w)
                self.print_weapon_list()
                break
            else:
                print("Please enter a number greater than 0")

    def edit_weapon(self):
        # This function edits a current character list of character objects
        if len(self.weapon_list) < 1:
            print("ERROR: There are no weapons")
            pass

        if len(self.weapon_list) >= 1:
            self.print_weapon_list()
            print("Which weapon would you like to edit?")
            edit_weap = 1 - int(input())
            print("You have selected: ", self.weapon_list[edit_weap].get_weapon_name())
            del self.weapon_list[edit_weap]
            w = Weapon()
            w.enter_weapon()
            self.weapon_list.append(w)
            self.print_weapon_list()
            pass

    def select_weapon(self):
        # this function selects a weapon from the list
        if len(self.weapon_list) < 1:
            print("ERROR: There are no weapons")
            pass

        if len(self.weapon_list) >= 1:
            self.print_weapon_list()
            print("Select your weapon of choice:")
            roll_weapon_choice = 1 - int(input())
            return roll_weapon_choice

    def rolling_damage(self, roll_weapon_choice):
        # this function rolls damage from an already selected weapon
        weapon_damage_total = 0
        for i in range(self.weapon_list[roll_weapon_choice].get_weapon_damage_dice_num()):
            weapon_damage = randint(1, self.weapon_list[roll_weapon_choice].get_weapon_damage_die())
            weapon_damage_total = weapon_damage_total + weapon_damage
        print(self.weapon_list[roll_weapon_choice].get_weapon_name(), ": ", weapon_damage_total, " ",
              self.weapon_list[roll_weapon_choice].get_weapon_damage_type())
