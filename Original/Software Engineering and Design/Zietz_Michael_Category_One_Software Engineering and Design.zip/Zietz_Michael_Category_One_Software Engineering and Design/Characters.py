from random import randint

class Character(object):
    character_list = []

    def __init__(self):
        self.character_name = ""
        self.ability_mod = 0
        self.bab = 0

    def enter_character(self):
        self.character_name = input("Please enter your character's name.\n")
        self.ability_mod = int(input("Please enter your Ability Score Modifier.\n"))
        self.bab = int(input("Please enter your Base Attack Bonus.\n"))

    def display_entered_characters(self):
        print("Character name: ", self.character_name)
        print("Character Ability Modifier: ", self.ability_mod)
        print("Character Base Attack Bonus: ", self.bab)

    def get_character_name(self):
        # This function returns a characters name from character_list
        return self.character_name

    def get_ability_mod(self):
        # This function returns a characters name from character_list
        return self.ability_mod

    def get_bab(self):
        # This function returns a characters name from character_list
        return self.bab

    def clear_character_list(self):
        # This function clears the character_list
        print("Character list has been cleared:")
        self.character_list.clear()
        return None

    def print_character_list(self):
        # This function prints the list of characters
        character_list_length = len(self.character_list)
        char_index = 0
        for i in range(character_list_length):
            char_index = char_index + 1
            print(char_index, ". ")
            self.character_list[i].display_entered_characters()
            print("")

    def add_character(self):
        # This function adds a new character object(s) to list of character objects
        num_of_characters_bool = True
        while num_of_characters_bool:
            num_of_characters = int(input("How many characters would you like to create? "))
            if num_of_characters >= 1:
                for i in range(num_of_characters):
                    c = Character()
                    c.enter_character()
                    self.character_list.append(c)
                self.print_character_list()
                break
            else:
                print("Please enter a whole number greater than 0")
        # if Y continue to rolling, but if N then point to select_character()

    def edit_character(self):
        # This function edits a current character list of character objects
        if len(self.character_list) < 1:
            return None

        if len(self.character_list) >= 1:
            self.print_character_list()
            print("Which character would you like to edit?")
            edit_char = 1 - int(input())
            print("You have selected: ", self.character_list[edit_char].get_character_name())
            del self.character_list[edit_char]
            c = Character()
            c.enter_character()
            self.character_list.append(c)
            self.print_character_list()
            pass

    def select_character(self):
        # This function selects an existing character object then use for rolling damage
        if len(self.character_list) < 1:
            print("ERROR: There are no characters")
            pass

        if len(self.character_list) >= 1:
            self.print_character_list()
            print("Please enter the number associated with the character you'd like to select ")
            roll_character_choice = 1 - int(input())
            return roll_character_choice

    def rolling_attack(self, roll_character_choice):
        # This function rolls to attack from an already selected character
        character_attack = randint(1, 20)
        if character_attack == 20:
            print(self.character_list[roll_character_choice].get_character_name(), " rolled a NAT 20!!!!!!!!")
            print(character_attack + self.character_list[roll_character_choice].get_ability_mod() +
                  self.character_list[roll_character_choice].get_bab())

        else:
            print(self.character_list[roll_character_choice].get_character_name(), " rolled: ", character_attack)
            print("Total to hit = ", character_attack + self.character_list[roll_character_choice].get_ability_mod() +
                  self.character_list[roll_character_choice].get_bab())
