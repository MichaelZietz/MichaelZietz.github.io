#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov 15 20:02:15 2023

@author: michaelzietz_snhu
"""

from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, USER, PASS):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        #USER = 'aacuser'
        #PASS = 'SNHU1234'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32582
        DB = 'aac'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
        print("Connection Successful")

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        #confirm data is not empty otherwise throws execption
        if len(data) < 1:
            return False
            
        elif data is not None:
            #inserts a single element with given data
            self.database.animals.insert_one(data)
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            
# Create method to implement the R in CRUD.
    def read(self, search):
        searchResult = [] # initialize sempty list so it can be filled or empty
        #confirm search data is not empty data otherwise throws execption
        if search is not None:
            #searches database and returns all matching entriess
            searchResult = self.database.animals.find(search)
        else:
            raise Exception("Nothing to read, because data parameter is empty")
        return searchResult # returns empty or filled list
    
# Create method to implement the U in CRUD
    def update(self, searchData, updateData):
        #confirm searchData is not empty data otherwise throws execption
        if searchData is not None:
            if searchData:
                #updates all specified entries and updates accordingly
                updateResult = self.database.animals.update_many(searchData, { "$set": updateData})
                return updateResult.raw_result
        else:
            raise Exception("Nothing to update, because data parameter is empty")
            
# Create a method to implement the D in CRUD
    def delete(self, search):
        #confirm search data is not empty data otherwise throws execption
        if search is not None:
            if search:
                #deletes all entries found possessing given search data
                deleteResult = self.database.animals.delete_many(search)
                return deleteResult.raw_result
        else:
            raise Exception("Nothing to delete, because data parameter is empty")